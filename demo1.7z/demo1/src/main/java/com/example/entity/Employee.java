package com.example.entity;

//import javax.persistence.*;

import java.util.List;

import jakarta.persistence.*;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

@Entity
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String employeeId;

    @Column(nullable = false)
    private String firstName;

    @Column(nullable = false)
    private String lastName;

    @Column(nullable = false)
    private String email;

    @ElementCollection
    private List<String> phoneNumbers;

    @Column(nullable = false)
    private String doj; // Date of joining

    @Column(nullable = false)
    private double salary;

    // getters and setters
}
