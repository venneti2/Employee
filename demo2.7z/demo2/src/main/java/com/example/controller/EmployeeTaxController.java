package com.example.controller;

import java.time.LocalDate;
import java.time.Month;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.*;

@RestController
class EmployeeTaxController {

    @GetMapping("/calculateTax")
    public Employee calculateTax(@RequestParam int employeeCode,
                                 @RequestParam String firstName,
                                 @RequestParam String lastName,
                                 @RequestParam double monthlySalary,
                                 @RequestParam String dateOfJoining) {
        // Parse dateOfJoining
        LocalDate joinDate = LocalDate.parse(dateOfJoining);

        // Calculate total salary considering DOJ
        LocalDate startOfFinancialYear = LocalDate.of(joinDate.getYear(), Month.APRIL, 1);
        LocalDate endOfFinancialYear = startOfFinancialYear.plusYears(1).minusDays(1);
        double totalSalary = monthlySalary * (endOfFinancialYear.getMonthValue() - joinDate.getMonthValue() + 1);

        // Calculate tax
        double taxAmount = calculateTaxAmount(totalSalary);

        // Calculate cess
        double cessAmount = calculateCess(totalSalary);

        // Create and return Employee object
        Employee employee = new Employee();
        employee.setEmployeeCode(employeeCode);
        employee.setFirstName(firstName);
        employee.setLastName(lastName);
        employee.setYearlySalary(totalSalary);
        employee.setTaxAmount(taxAmount);
        employee.setCessAmount(cessAmount);

        return employee;
    }

    private double calculateTaxAmount(double yearlySalary) {
        double taxAmount = 0;
        if (yearlySalary > 250000 && yearlySalary <= 500000) {
            taxAmount = (yearlySalary - 250000) * 0.05;
        } else if (yearlySalary > 500000 && yearlySalary <= 1000000) {
            taxAmount = 12500 + (yearlySalary - 500000) * 0.1;
        } else if (yearlySalary > 1000000) {
            taxAmount = 62500 + (yearlySalary - 1000000) * 0.2;
        }
        return taxAmount;
    }

    private double calculateCess(double yearlySalary) {
        double cessAmount = 0;
        if (yearlySalary > 2500000) {
            cessAmount = (yearlySalary - 2500000) * 0.02;
        }
        return cessAmount;
    }
}






